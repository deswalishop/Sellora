"use client";

/** WhatsApp + Instagram brand icons (inline SVG, no emoji). */
export function WhatsAppIcon({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z" />
    </svg>
  );
}

export function InstagramIcon({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
    </svg>
  );
}

/** Floating WhatsApp chat button (PRD: WhatsApp commerce, D2 wa.me links). */
export function WhatsAppFloat({ phone, storeName }: { phone: string; storeName: string }) {
  const d = phone.replace(/\D/g, "");
  const num = d.startsWith("92") ? d : d.startsWith("0") ? "92" + d.slice(1) : d;
  return (
    <a
      href={`https://wa.me/${num}?text=${encodeURIComponent(`Assalam-o-Alaikum! I have a question about ${storeName}.`)}`}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat on WhatsApp"
      className="fixed bottom-5 right-5 z-30 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-lg transition hover:scale-105"
    >
      <WhatsAppIcon size={28} />
    </a>
  );
}

/** Share a product on WhatsApp / Instagram. */
export function ShareButtons({ title, url, brandColor }: { title: string; url: string; brandColor: string }) {
  const waHref = `https://wa.me/?text=${encodeURIComponent(`${title} — ${url}`)}`;
  return (
    <div className="flex items-center gap-2">
      <span className="text-xs font-medium text-muted">Share:</span>
      <a
        href={waHref}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Share on WhatsApp"
        className="flex h-9 w-9 items-center justify-center rounded-full bg-[#25D366]/15 text-[#1da851] transition hover:bg-[#25D366]/25"
      >
        <WhatsAppIcon size={18} />
      </a>
      <button
        type="button"
        aria-label="Copy link for Instagram"
        onClick={() => {
          navigator.clipboard?.writeText(`${title} — ${url}`).catch(() => {});
        }}
        className="flex h-9 w-9 items-center justify-center rounded-full bg-pink-500/10 text-pink-600 transition hover:bg-pink-500/20"
        title="Copy link to share on Instagram"
      >
        <InstagramIcon size={18} />
      </button>
    </div>
  );
}
